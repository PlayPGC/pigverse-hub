function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '40px' }}>
      <h1>Welcome to PigVerse Hub</h1>
      <p>This is your React-powered frontend for NFT minting.</p>
    </div>
  )
}

export default App